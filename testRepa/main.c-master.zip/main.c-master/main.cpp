#include <stdio.h>
#include <string.h>

int main(){
printf("Hello, World!!!");
printf("Hello, World");
return 0;}
